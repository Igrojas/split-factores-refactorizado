"""Ejemplos de uso de splitfactor."""
