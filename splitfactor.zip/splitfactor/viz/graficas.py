"""
Módulo de visualización para resultados de simulación.

Gráficas disponibles:
- Nube de recuperación vs ley
- Split factors
- Comparación con test de dilución
- Top N mejores simulaciones
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple


# Configuración visual por defecto
COLORES_DEFAULT = {
    'Día': 'orange',
    'Noche': 'blue',
    'Promedio': 'green'
}

MARCADORES_DEFAULT = {
    'Día': 'D',
    'Noche': 's',
    'Promedio': 'o'
}

COLORES_TOP10 = [
    '#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231',
    '#911eb4', '#42d4f4', '#f032e6', '#bfef45', '#fabed4'
]


def configurar_estilo():
    """Aplica estilo visual consistente."""
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams['figure.figsize'] = (10, 6)
    plt.rcParams['font.size'] = 11
    plt.rcParams['axes.titlesize'] = 12
    plt.rcParams['axes.labelsize'] = 11


def graficar_recuperacion_ley(
    df: pd.DataFrame,
    col_recuperacion: str = 'recuperacion',
    col_ley: str = 'ley_concentrado',
    titulo: str = 'Recuperación vs Ley de Concentrado',
    color: str = 'steelblue',
    alpha: float = 0.5,
    ax: Optional[plt.Axes] = None
) -> plt.Axes:
    """
    Gráfica de dispersión: Recuperación vs Ley de concentrado.
    
    Args:
        df: DataFrame con resultados
        col_recuperacion: Nombre de columna de recuperación
        col_ley: Nombre de columna de ley
        titulo: Título del gráfico
        color: Color de los puntos
        alpha: Transparencia
        ax: Axes existente (opcional)
    
    Returns:
        Axes del gráfico
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    
    ax.scatter(
        df[col_recuperacion],
        df[col_ley],
        c=color,
        alpha=alpha,
        s=20,
        edgecolors='none'
    )
    
    ax.set_xlabel('Recuperación (%)')
    ax.set_ylabel('Ley de Concentrado (%)')
    ax.set_title(titulo)
    ax.grid(True, alpha=0.3)
    
    return ax


def graficar_splits(
    df: pd.DataFrame,
    equipo: str,
    col_masa: Optional[str] = None,
    col_cuf: Optional[str] = None,
    color_por: Optional[str] = None,
    titulo: Optional[str] = None,
    ax: Optional[plt.Axes] = None
) -> plt.Axes:
    """
    Gráfica de split factors: masa vs contenido fino.
    
    Args:
        df: DataFrame con resultados MC
        equipo: Nombre del equipo
        col_masa: Columna de split masa (default: '{equipo}_sp_masa')
        col_cuf: Columna de split cuf (default: '{equipo}_sp_cuf')
        color_por: Columna para colorear puntos
        titulo: Título del gráfico
        ax: Axes existente
    
    Returns:
        Axes del gráfico
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))
    
    col_masa = col_masa or f'{equipo}_sp_masa'
    col_cuf = col_cuf or f'{equipo}_sp_cuf'
    titulo = titulo or f'Split Factors - {equipo}'
    
    if color_por and color_por in df.columns:
        scatter = ax.scatter(
            df[col_masa],
            df[col_cuf],
            c=df[color_por],
            cmap='viridis',
            alpha=0.6,
            s=20
        )
        plt.colorbar(scatter, ax=ax, label=color_por)
    else:
        ax.scatter(
            df[col_masa],
            df[col_cuf],
            c='steelblue',
            alpha=0.5,
            s=20
        )
    
    ax.set_xlabel('Split Masa')
    ax.set_ylabel('Split CuF')
    ax.set_title(titulo)
    ax.grid(True, alpha=0.3)
    
    return ax


def graficar_con_test_dilucion(
    df_mc: pd.DataFrame,
    df_test: pd.DataFrame,
    col_rec_mc: str = 'recuperacion',
    col_ley_mc: str = 'ley_concentrado',
    col_rec_test: str = 'Recuperación, Cu%',
    col_ley_test: str = 'Ley acumulada, Cu%',
    ley_alim_test: Optional[float] = None,
    titulo: str = 'Simulación MC vs Test de Dilución',
    ax: Optional[plt.Axes] = None
) -> plt.Axes:
    """
    Gráfica comparando simulación MC con test de dilución.
    
    Args:
        df_mc: DataFrame de Monte Carlo
        df_test: DataFrame de test de dilución
        col_rec_mc, col_ley_mc: Columnas de MC
        col_rec_test, col_ley_test: Columnas de test
        ley_alim_test: Ley de alimentación del test (para leyenda)
        titulo: Título
        ax: Axes existente
    
    Returns:
        Axes del gráfico
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    
    # Nube de MC
    ax.scatter(
        df_mc[col_rec_mc],
        df_mc[col_ley_mc],
        c='lightgray',
        alpha=0.5,
        s=15,
        label='Simulación MC'
    )
    
    # Curva de test de dilución
    label_test = 'Test de Dilución'
    if ley_alim_test:
        label_test += f' (Ley Alim = {ley_alim_test:.2f}%)'
    
    sns.lineplot(
        data=df_test,
        x=col_rec_test,
        y=col_ley_test,
        color='royalblue',
        marker='D',
        markersize=8,
        linestyle='--',
        linewidth=2,
        label=label_test,
        ax=ax
    )
    
    ax.set_xlabel('Recuperación (%)')
    ax.set_ylabel('Ley de Concentrado (%)')
    ax.set_title(titulo)
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    return ax


def graficar_top_n(
    df: pd.DataFrame,
    n: int = 10,
    criterio: str = 'razon_enriquecimiento',
    col_x: str = 'recuperacion',
    col_y: str = 'ley_concentrado',
    ascendente: bool = False,
    ax: Optional[plt.Axes] = None
) -> Tuple[plt.Axes, pd.DataFrame]:
    """
    Destaca las top N simulaciones según un criterio.
    
    Args:
        df: DataFrame con resultados
        n: Número de top a mostrar
        criterio: Columna para ordenar
        col_x, col_y: Columnas para ejes
        ascendente: Orden ascendente (False = mayor es mejor)
        ax: Axes existente
    
    Returns:
        (Axes, DataFrame con top N)
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    
    # Ordenar y obtener top N
    df_sorted = df.sort_values(criterio, ascending=ascendente)
    df_top = df_sorted.head(n).copy()
    df_resto = df_sorted.iloc[n:]
    
    # Graficar resto en gris
    ax.scatter(
        df_resto[col_x],
        df_resto[col_y],
        c='lightgray',
        alpha=0.5,
        s=15,
        label='Resto'
    )
    
    # Graficar top N con colores
    for i, (idx, row) in enumerate(df_top.iterrows()):
        color = COLORES_TOP10[i % len(COLORES_TOP10)]
        ax.scatter(
            row[col_x],
            row[col_y],
            c=color,
            s=100,
            marker='o',
            edgecolors='black',
            linewidth=1.5,
            label=f'Top {i+1}',
            zorder=10
        )
    
    ax.set_xlabel('Recuperación (%)')
    ax.set_ylabel('Ley de Concentrado (%)')
    ax.set_title(f'Top {n} por {criterio}')
    ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    ax.grid(True, alpha=0.3)
    
    return ax, df_top


def crear_figura_resumen(
    df_mc: pd.DataFrame,
    df_normal: Optional[pd.DataFrame] = None,
    df_test: Optional[pd.DataFrame] = None,
    equipo_split: str = 'Jameson 1',
    turno: str = '',
    figsize: Tuple[int, int] = (14, 6)
) -> plt.Figure:
    """
    Crea figura con 2 subplots: splits y recuperación/ley.
    
    Args:
        df_mc: Resultados Monte Carlo
        df_normal: Resultados simulación normal (opcional)
        df_test: Datos test de dilución (opcional)
        equipo_split: Equipo para graficar splits
        turno: Nombre del turno para título
        figsize: Tamaño de figura
    
    Returns:
        Figura matplotlib
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
    
    # Subplot 1: Split factors
    col_masa = f'{equipo_split}_sp_masa'
    col_cuf = f'{equipo_split}_sp_cuf'
    
    if col_masa in df_mc.columns and col_cuf in df_mc.columns:
        graficar_splits(
            df_mc, equipo_split,
            color_por='razon_enriquecimiento',
            titulo=f'Split Factors {equipo_split} - {turno}',
            ax=ax1
        )
    else:
        ax1.text(0.5, 0.5, 'Sin datos de splits', ha='center', va='center')
    
    # Subplot 2: Recuperación vs Ley
    ax2.scatter(
        df_mc['recuperacion'],
        df_mc['ley_concentrado'],
        c='lightgray',
        alpha=0.5,
        s=15,
        label='MC'
    )
    
    # Agregar simulación normal si existe
    if df_normal is not None and not df_normal.empty:
        ax2.scatter(
            df_normal['recuperacion'],
            df_normal['ley_concentrado'],
            c='red',
            marker='*',
            s=200,
            edgecolors='black',
            linewidth=1.5,
            label='Simulación Base',
            zorder=10
        )
    
    # Agregar test de dilución si existe
    if df_test is not None and not df_test.empty:
        sns.lineplot(
            data=df_test,
            x='Recuperación, Cu%',
            y='Ley acumulada, Cu%',
            color='royalblue',
            marker='D',
            markersize=6,
            linestyle='--',
            label='Test Dilución',
            ax=ax2
        )
    
    ax2.set_xlabel('Recuperación (%)')
    ax2.set_ylabel('Ley de Concentrado (%)')
    ax2.set_title(f'Recuperación vs Ley - {turno}')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    return fig


def guardar_figura(fig: plt.Figure, ruta: str, dpi: int = 150):
    """Guarda figura en archivo."""
    fig.savefig(ruta, dpi=dpi, bbox_inches='tight')
    print(f"Figura guardada: {ruta}")
